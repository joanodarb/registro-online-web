<?php
// includes/footer.php
?>
    <footer>
        <div class="container">
            <p>&copy; <?= date('Y') ?> <?= APP_NAME ?>. Todos los derechos reservados.</p>
        </div>
    </footer>
</body>
</html>